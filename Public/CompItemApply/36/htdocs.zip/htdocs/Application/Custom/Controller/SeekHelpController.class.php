<?php
namespace Custom\Controller;
use Custom\Common\Controller\CommonController;
class SeekHelpController extends CommonController {
	public function SeekHelp(){
		//显示__app__/Custom/SeekHelp/SeekHelp页面
		$this->display();
	}
}