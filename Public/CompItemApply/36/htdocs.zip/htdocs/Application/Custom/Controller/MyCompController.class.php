<?php
namespace Custom\Controller;
use Custom\Common\Controller\CommonController;

class MyCompController extends CommonController {

	
	public function myComp(){
		//显示__app__/home/comp/myComp页面
		$this->display();
	}
	
	/**
	 * 获取个人竞赛信息（不包含具体内容，仅返回竞赛名称等最基本信息）
	 */
	public function getCompItem() {
		$compItemModel = M('ecnu_mind.competition_main');
		$compInfoModel = M('ecnu_mind.competition_info');
	
		// 设置查询条件
		$map['comp_participant_id'] = array('like', '%'.session('student_id').'%') ;
		
		// 获取报名的基本信息
		$compBaseInfo = $compItemModel->where($map)->select();
				
		foreach ($compBaseInfo as $compBase) {
			// 获得该项竞赛的基本信息
			$compinfo =	$compInfoModel
						->where('comp_id='.$compBase['comp_type_id'])
						->field("comp_name")
						->find();
						
			/// 添加其他竞赛信息			
			// 返回竞赛名和竞赛报名日期和报名当前状态。
			$returnItem['comp_name'] = $compinfo['comp_name'];
			$returnItem['apply_date'] = $compBase['apply_date'];
			$returnItem['comp_state'] = $compBase['comp_state'];
			if ($compBase['comp_item_name'] == '') 
				$returnItem['comp_item_name'] = '无题';
			else 
				$returnItem['comp_item_name'] = $compBase['comp_item_name'];
			
			$returnItem['comp_template'] = 
				U("Custom/CompApply/showUpdateView","compItemId=".$compBase['comp_item_id'],"");
			
			$returnItem['comp_remove'] =
				U("Custom/CompApply/removeApply","compItemId=".$compBase['comp_item_id'],"");
			
			$returnItem['comp_item_id'] = $compBase['comp_item_id'];
			
			$result[] = $returnItem; 
		}
		
		$this->ajaxReturn(json_encode($result), "EVAL");
		
	}
}