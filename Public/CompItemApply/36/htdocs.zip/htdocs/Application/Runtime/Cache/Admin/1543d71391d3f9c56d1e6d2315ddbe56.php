<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
  <meta http-equiv = "X-UA-Compatible" content = "chrome=1" />
  <meta charset="utf-8" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/UserControl.css"/>
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap.min.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table-filter.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/Personmain.css"/>
  
  
  <script src="/Public/jsLib/jquery/Chart.js"></script>
  <script src="/Public/jslib/jquery/jquery.min.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap.min.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap-table-filter.js"></script>
  <script src="/Public/jslib/bootstrap/ext/bs-table.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap-table.js"></script>
  <script src="/Public/jslib/bootstrap/ext/plugin-bs-table.js"></script>
  <script src="/Public/jslib/bootstrap/ext/bootstrap-table-zh-CN.js"></script>
  <script src="/Public/jsLib/bootstrap/ext/tableExport.js"></script>
  <script src="/Public/jsLib/bootstrap/ext/jquery.base64.js"></script>
  <script src="/Public/jsLib/bootstrap/ext/html2canvas.js"></script>
  <script src="/Public/jsLib/bootstrap/ext/exportPlugin.js"></script>
  
  <link rel="stylesheet" type="text/css" href="/Public/jsLib/tooltipster-master/css/tooltipster.css" />
  <link rel="stylesheet" type="text/css" href="/Public/jsLib/tooltipster-master/css/themes/tooltipster-noir.css" />
  <script type="text/javascript" src="/Public/jsLib/tooltipster-master/js/jquery.tooltipster.min.js"></script>
  
  <script>
	var admin = "<?php echo ($admin_access); ?>";
  </script>
  <script>
  	var APP_URL = "";
  	var PUBLIC_URL = "/Public";
  </script>
</head>

<body style="background-color: #fff">
  <div style="margin:10px 15px 15px;">
	<div id="filter-bar"> </div>
    <table id="comp-table" 
           data-url="/Admin/UserControl/showAllUser"
           data-toolbar="#filter-bar" 
           data-show-toggle="true" 
           data-search="true"           
           data-show-filter="true"
           data-striped="true"
           data-sort-name="apply_state" 
           data-sort-order="desc"
           data-pagination="true"
           data-toolbar="#custom-toolbar"
           data-show-export="true">
      <thead>
        <tr>
          <th data-field="name" data-width="100" data-align="left" data-sortable="true" data-sorter="starSorter" 
          				data-formatter="operateFormatter" data-events="operateEvents">姓名</th>
          <th data-field="student_id" data-width="140" data-align="left">学号</th>
          <th data-field="academy" data-width="200" data-align="left">学院</th>
          <th data-field="department" data-width="200" data-align="left">系别</th>
          <th data-field="major" data-width="200" data-align="left">专业</th>
          <th data-field="phone" data-width="140" data-align="left">手机</th>
          <th data-field="email" data-width="200" data-align="left">邮箱</th>
          <th data-field="user_id" data-width="50" data-align="left">user_id</th>
          
        </tr>
      </thead>
    </table>
  </div>

<div class="personMainModal">
	<div class="box1">
		<div class="title_box">
			<div style="display:inline-block;width:15px;height:15px;">
				<img style="width:15px;height:15px;margin-left: -10px;" src="/Public/img/icon/myinfo.png">
			</div>个人详细信息
		</div>
		<div class="photo"></div>
		<div class="personMainDetail">
			<div class="personMainUpperShell">
				<div class="personMainName"></div>
				<div class="personMainGender"></div>
			</div>
			<div class="personMainDetailLeft">
				<div class="personMainDetailLeft-line personMainMajor"></div>
				<div class="personMainDetailLeft-line personMainStudendID"></div>
				<div class="personMainDetailLeft-line personMainMail"></div>
				<div class="personMainDetailLeft-line personMainPhone"></div>
			</div>
			<div class="personMainDetailRight">
				<div class="personMainDetailRight-line personMainSchoolingSys"></div>
				<div class="personMainDetailRight-line personMainGrade"></div>
				<div class="personMainDetailRight-line personMainCampus"></div>
				<div class="personMainDetailRight-line personMainAddress"></div>
			</div>
		</div>		
	</div>
	<div class="box2">
		<div class="title_box">
			<div style="display:inline-block;width:15px;height:15px;">
				<img style="width:15px;height:15px;margin-left: -10px;" src="/Public/img/icon/myinfo.png">
			</div>能力概览
		</div>
		<div class="Chart">
			<div class="Chart_info">
				<p style="font-size: 10px;color: #0080ff;text-align:center">tips:鼠标悬浮在图上以显示详细能力信息~</p>
				<canvas id="chart-area" width="300" height="300" style="width: 240px; height: 240px;"></canvas>
			</div>
			<div class="tips">
				<!-- 等待UserControl.js生成div -->
			</div>
			<div class="detail">
				<div id="default">
					请单击左侧饼图以查看能力详情
				</div>
				<!-- 等待UserControl.js生成div -->
			</div>
		</div>
	</div>
	<div class="personMainModal-close">点此收起↑</div>	
</div>
  
  <script src="/Public/js/Admin/UserControl.js"></script>
</body>

</html>