<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta http-equiv = "X-UA-Compatible" content = "chrome=1" />
<meta charset="UTF-8">
<title>Personal photo</title>
  <link rel="Stylesheet" type="text/css" href="/Public/css/Personalphoto.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/jsLib/myAlert/myAlert.css"/>
  <link rel='Stylesheet' type='text/css' href='/Public/jsLib/jquery/Jcrop/jquery.Jcrop.min.css'>
  <script src="/Public/jsLib/jquery/jquery.min.js"></script>
  <script src="/Public/jsLib/jquery/ajaxfileupload.js"></script>
  <script type="text/javascript" src="/Public/jsLib/jquery/cropbox.js"></script>
  <script type="text/javascript" src="/Public/js/home/InitPersonalPhoto.js"></script>
  <script src="/Public/jsLib/myAlert/myAlert.js"></script>
  <script type="text/javascript">
  	var modelUrl = "/custom/personal_photo";
  </script>
</head>

<body>
	<div class='title_box'>
	  <div style="display:inline-block;width:15px;height:15px;">
	    <img style="width:15px;height:15px;margin-left:-10px;" src ="/Public/img/icon/base.png">
	  </div>
	    个人照片上传
	</div>
  	  <div class='Page-box clearfix' id='Page2'>
    
    <div class='head' >
      <p>个人头像管理</p>	
    </div>
    
    <div class='form-box' >
      <div class='Old'>
        <p>当前使用</p>
        <div class='photo' style='width: 120px;height: 120px;margin: 0 auto;'>
          <img src='/Public/img/photo/<?php echo ($photo_id); ?>/face.png?timeTmp=<?php echo ($time); ?>' alt='照片载入失败' style="width:100%;height:100%">
        </div>	        
      </div>
      
      <div class='New'>
        <div class="container">
		  <div class="imageBox">
		    <div class="thumbBox"></div>
		    <div class="spinner" style="display: none"></div>
		  </div>
		  <div class="action"> 
		    <!-- <input type="file" id="file" style=" width: 200px">-->
		    <div class="new-contentarea tc"> <a href="javascript:void(0)" class="upload-img">
		      <label for="upload-file">选择图片</label>
		      </a>
		      <input type="file" name="upload-file" id="upload-file" style="cursor: pointer"/>
		    </div>
		    <input type="button"  id="btnOK"  class="Btnsty_peyton" value="OK">
		    <input type="button" id="btnZoomIn" class="Btnsty_peyton" value="+"  >
		    <input type="button" id="btnZoomOut" class="Btnsty_peyton" value="-" >
		  </div>
		</div>
      </div>
    </div>
	<div class="help">
      <p style="text-align: center; color: #bb0000; font-weight: 600;">照片上传说明</p>
      <p style="color: #333;"><span>※</span> 请不要上传超过200x200的照片</p>
      <p style="color: #333;"><span>※</span> 请使用真实的、且能看清面部的本人照片</p>
      <p style="color: #333;"><span>※</span> 您可以在选择图片完成后进行裁剪操作</p>
      <p style="color: #333;"><span>※</span> 严禁使用违规违法图片</p>
    </div>
  </div>
  	<div class='messagePopOut' style='display:none'>
	   	<div class='messagePopText'>
	   		
	   	</div>
	   	<div class='messagePopButton'>
	   		OK
	   	</div>  
    </div>
</body>
</html>