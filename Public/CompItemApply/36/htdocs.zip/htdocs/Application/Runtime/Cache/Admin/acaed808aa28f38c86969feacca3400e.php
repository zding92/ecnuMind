<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
  <meta http-equiv = "X-UA-Compatible" content = "chrome=1" />
  <meta charset="utf-8" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap.min.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table-filter.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/jsLib/myAlert/myAlert.css"/>
  <link rel="Stylesheet" type="text/css" href="/Public/css/Note.css"/>
  
  <script src="/Public/jslib/jquery/jquery.min.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap.min.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap-table-filter.js"></script>
  <script src="/Public/jslib/bootstrap/ext/bs-table.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap-table.js"></script>
  <script src="/Public/jslib/bootstrap/ext/plugin-bs-table.js"></script>
  <script src="/Public/jslib/bootstrap/ext/bootstrap-table-zh-CN.js"></script>
  <script src="/Public/jsLib/myAlert/myAlert.js"></script>
  
  <script>
  	var getDataURL = '/Home/Comp/getCompItem';
	var admin = "<?php echo ($admin_access); ?>";
  </script>
</head>

<body style="background-color: #fff">
  <div id="custom-toolbar"  style="width:110px;">
  	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#noteModal" id='btn_addNote' style="float:right">发送新的通知</button>
  </div>
  <div style="margin:10px 15px 15px;">
    <div id="filter-bar"> </div>
    <table id="note-table" 
   		   data-url="/admin/notification/getNoteInfo"
           data-toolbar="#custom-toolbar" 
           data-show-toggle="true" 
           data-search="true"           
           data-show-filter="true"
           data-striped="true"
           data-sort-name="note_time" 
           data-sort-order="desc">
      <thead>
        <tr>
          <th data-field="note_id" data-width="100" data-align="left">通知ID</th>
          <th data-field="user_id" data-width="100" data-align="left">管理员ID</th>
          <th data-field="note_time" data-width="200" data-align="left" data-sortable="true">通知时间</th>
          <th data-field="note_title" data-width="300" data-align="left">通知标题</th>
          <th data-formatter="detailFormatter" data-events="detailEvents" data-width="100" data-align="left">通知内容</th>
          <th data-field="operate" data-width="100" data-formatter="removeFormatter" data-events="removeEvents">操作</th>
    </tr>
        </tr>
      </thead>
    </table>
  </div>
  
  <div class="modal fade" id="detailModal" tabindex="-1" role="dialog" 
	   aria-labelledby="myModalLabel" aria-hidden="true">
	   <div class="modal-dialog">
	      <div class="modal-content">
	         <div class="modal-header">
	            <button type="button" class="close" data-dismiss="modal" 
	               aria-hidden="true">×
	            </button>
	            <h4 class="modal-title" id="myModalLabel">
	              	通知内容
	            </h4>
	         </div>
	         <div class="modal-body" id="detailShowContent">
	          
			</div>
	         <div class="modal-footer">
	            <button type="button" class="btn btn-default" 
	               data-dismiss="modal">关闭
	            </button>
	            <button type="button" class="btn btn-primary" id='sendConfirm' data-dismiss="modal" >
	              确认
	            </button>
	         </div>
	      </div>
	   </div>
	</div>
  
  <div class="modal fade" id="noteModal" tabindex="-1" role="dialog" 
	   aria-labelledby="myModalLabel" aria-hidden="true">
	   <div class="modal-dialog">
	      <div class="modal-content">
	         <div class="modal-header">
	            <button type="button" class="close" data-dismiss="modal" 
	               aria-hidden="true">×
	            </button>
	            <h4 class="modal-title" id="myModalLabel">
	              	发起通知
	            </h4>
	         </div>
	         <div class="modal-body">
	         <form class="bs-example bs-example-form" role="form" id="addNoteForm">				
	         <div class="input-group">
	         	<button class="btn btn-default" style="position:absolute;" type="button" id='recipient' data-toggle="modal" data-target="#recipientModal" style="display:none;">选择收件院系</button>
				<p class="academySelected" id="academySelected"> </p>
				</div>
	         	<br>
	         	<div class="input-group">
			         <span class="input-group-addon">标题</span>
			         <input type="text" class="form-control comp_sponsor" id="admin_note_title" maxlength="30" placeholder="填写标题">
			      </div>
			    <br>
			    <div class="input-group">
			    	<span class="input-group-addon">内容</span>
			    	<textarea class="form-control comp_sponsor" id="admin_note_detail" style="resize:none;width:500px;height:250px" maxlength="500" placeholder="填写内容"></textarea>
			    </div>  
	         </form>
			</div>
	         <div class="modal-footer">
	            <button type="button" class="btn btn-default" 
	               data-dismiss="modal">关闭
	            </button>
	            <button type="button" class="btn btn-primary" id='sendConfirm' data-dismiss="modal" data-toggle="modal" data-target="#confirmModal">
	              发送
	            </button>
	         </div>
	      </div>
	   </div>
	</div>
	
	
	<div class="modal fade" id="recipientModal" tabindex="-1" role="dialog" 
	   aria-labelledby="myModalLabel" aria-hidden="true">
	   <div class="modal-dialog">
	      <div class="modal-content">
	         <div class="modal-header">
	           <button type="button" class="close" data-dismiss="modal" 
	               aria-hidden="true">×
	            </button>
	            <h4 class="modal-title" id="myModalLabel">
	              	选择收件院系
	            </h4>
	         </div>
	         <div class="modal-body">
	           <div style="margin:10px 15px 15px;">
	           		<div id="recipient-bar"> </div>
	        		<div id="recipient-filter"> </div>
	         		<table id="recipient-table"
	         		   data-url="/admin/notification/showRecipient"
	         		   data-toolbar="#recipient-bar"
	         		   data-search="true"
	         		   data-striped="true"
	         		   data-show-filter="true"
	         		   data-click-to-select="true">
	         		<thead>
	         			<tr>
	         				<th data-field="state" data-checkbox="true"></th>
	         				<th data-field="name">学院名称</th>
	         				<th data-field="academy_id"></th>
	         			</tr>
	         		</thead>
	         	</table>          
	           </div>	
	         </div>
	         <div class="modal-footer">
	            <button type="button" id='recipient_close' class="btn btn-default" 
	               data-dismiss="modal" onclick="btnOnclick(this.id)">关闭
	            </button>
	            <button type="button" class="btn btn-primary" id='recipientConfirm' data-dismiss="modal" onClick="btnOnclick(this.id)">
	               确认
	            </button>
	         </div>
	      </div><!-- /.modal-content -->
	   </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	
	
	
	<div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" 
	   aria-labelledby="myModalLabel" aria-hidden="true">
	   <div class="modal-dialog">
	      <div class="modal-content">
	         <div class="modal-header">
	            <button type="button" class="close" data-dismiss="modal" 
	               aria-hidden="true">×
	            </button>
	            <h4 class="modal-title" id="myModalLabel">
	              	提示
	            </h4>
	         </div>
	         <div class="modal-body">
	            您确定进行发送通知的操作么？
	         </div>
	         <div class="modal-footer">
	            <button type="button" class="btn btn-default" 
	               data-dismiss="modal">关闭
	            </button>
	            <button type="button" class="btn btn-primary" id='noteConfirm' data-dismiss="modal" onclick="btnOnclick(this.id)">
	               确认
	            </button>
	         </div>
	      </div><!-- /.modal-content -->
	   </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	
	<div class='messagePopOut' style='display:none'>
         	<div class='messagePopText'>
         		
         	</div>
         	<div class='messagePopButton'>
         		OK
         	</div>        	
   </div>
  <script src="/Public/js/Admin/Notification.js"></script>
   <script>var notification_url = "/admin/notification/noteSave";</script>
   <script>var remove_url = "/admin/notification/noteRemove";</script>
</body>

</html>