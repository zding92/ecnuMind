<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
  <meta http-equiv = "X-UA-Compatible" content = "chrome=1" />
  <meta charset="utf-8" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap.min.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table.css" />
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table-filter.css" />
  
  <script src="/Public/jslib/jquery/jquery.min.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap.min.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap-table-filter.js"></script>
  <script src="/Public/jslib/bootstrap/ext/bs-table.js"></script>
  <script src="/Public/jslib/bootstrap/bootstrap-table.js"></script>
  <script src="/Public/jslib/bootstrap/ext/plugin-bs-table.js"></script>
  <script src="/Public/jslib/bootstrap/ext/bootstrap-table-zh-CN.js"></script>
  <script type="text/javascript">
  	var model = "/custom/comp";
  	var publicUrl = "/Public";
  	var compFormUrl = "/Public/CompForm/";
  </script>
  
</head>

<body style="background-color: #fff">
  <div style="margin:10px 15px 15px;">
    <div id="filter-bar"> </div>
    <table id="comp-table" 
           data-url="/custom/comp/getCompInfo"
           data-toolbar="#filter-bar" 
           data-show-toggle="true" 
           data-search="true"           
           data-show-filter="true"
           data-striped="true"
           data-sort-name="apply_state" 
           data-sort-order="desc">
      <thead>
        <tr>
          <th data-field="comp_importance" data-width="100" data-align="left" data-sortable="true" data-sorter="starSorter">竞赛评级</th>
          <th data-field="comp_name" data-width="350" data-align="left">竞赛名称</th>
          <th data-field="comp_field" data-width="100" data-align="left">竞赛类型</th>
          <th data-field="comp_template" data-width="100" data-align="left">报名链接</th>
          <th data-field="operate" data-formatter="operateFormatter" data-width="50">附件下载</th>
          <th data-field="apply_date" data-width="200" data-align="center">报名起止日期</th>
          <th data-field="apply_state" data-width="0" data-sortable="true" data-order="desc" data-align="left">报名状态</th>
        </tr>
      </thead>
    </table>
  </div>
  <script src="/Public/js/Comp/Comp.js"></script>
</body>

</html>