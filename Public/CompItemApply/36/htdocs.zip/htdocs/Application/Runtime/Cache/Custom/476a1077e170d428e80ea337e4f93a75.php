<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta http-equiv = "X-UA-Compatible" content = "chrome=1" />
	<meta charset="UTF-8">
	<title>竞赛报名</title>
	<link rel="stylesheet" href="/Public/jsLib/SweetAlert/sweetalert.css" type='text/css'>
	<link href="/Public/css/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="/Public/css/compApply.css" rel="stylesheet">
	<script src="/Public/jsLib/jquery/jquery.min.js"></script>
	<script src="/Public/js/home/compApply.js"></script>
	<script src="/Public/jsLib/bootstrap/bootstrap.min.js"></script>
	<script type="text/javascript" src="/Public/jsLib/SweetAlert/sweetalert.min.js"></script>
	<script>
		var model = "/custom/comp_apply";
		var publicUrl = "/Public"
		var comp_item_file_url="/Public/CompItemApply/"
		var addSuccess = <?php echo ($addSuccess); ?>;
		var submitMode = "<?php echo ($submitMode); ?>";
	</script>
	<style type="text/css">
	    /* Custom Styles */
	    ul.nav-tabs{
	        width: 140px;
	        margin-top: 20px;
	        border-radius: 4px;
	        border: 1px solid #ddd;
	        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.067);
	    }
	    ul.nav-tabs li{
	        margin: 0;
	        border-top: 1px solid #ddd;
	    }
	    ul.nav-tabs li:first-child{
	        border-top: none;
	    }
	    ul.nav-tabs li a{
	        margin: 0;
	        padding: 8px 16px;
	        border-radius: 0;
	    }
	    ul.nav-tabs li.active a, ul.nav-tabs li.active a:hover{
	        color: #fff;
	        background: #0088cc;
	        border: 1px solid #0088cc;
	    }
	    ul.nav-tabs li:first-child a{
	        border-radius: 4px 4px 0 0;
	    }
	    ul.nav-tabs li:last-child a{
	        border-radius: 0 0 4px 4px;
	    }
	    ul.nav-tabs.affix{
	        top: 30px; /* Set the top position of pinned element */
	    }
	</style>
</head>
<body data-spy="scroll" data-target="#myScrollspy">
<div class="container">	
	<div class="jumbotron">
        <h1><?php echo ($compName); ?>  报名系统</h1>
    </div>
    <div class="row">
        <div class="col-xs-3" id="myScrollspy">
            <ul class="nav nav-tabs nav-stacked" id="myNav">
                <li class="active"><a href="#section-1">竞赛说明</a></li>
                <li><a href="#section-2">基本信息</a></li>
                <li><a href="#section-3">参赛作品简介</a></li>
                <li><a href="#section-4">附件提交</a></li>
            </ul>
             <ul class="nav nav-stacked"   id="saveBtn">
            	<li><button class='btn btn-success btn-lg saveBtn'>保存</button></li>
            </ul>
        </div>
        
        <div class="col-xs-9">
          <form id="applyForm" method="post">
            <h2 id="section-1">竞赛说明</h2>
            <div style="border-top: 1px solid #ddd">
              <p id="introduction">
                	<?php echo ($comp_brief); ?>
              </p>
            </div>
            <h2 id="section-2">基本信息</h2>
            <div style="border-top: 1px solid #ddd">
              <p>
              	<label class='nameLabel' for='comp_item_name' style="width:125px">作品名称</label>
                <input type='text' placeholder='竞赛作品名称，如果是比赛现场作品，可以不填'  name='comp_item_name'  id='comp_item_name'>
              </p>
              <p id="memberInfo">
              	<label class='memberLabel' for='a1' style="width:125px">第一参赛者</label>
              	<input type='text' placeholder='请输入作者学号'  name='a1'  id='a1'>
              	<br>
              	<button type="button" class="btn btn-primary btn-lg" id="newParticipant">
				  <!-- <span class="glyphicon glyphicon-plus"></span>  -->+ 添加参与者
				</button>
				<label class="pCount" id="peopleCnt"><span id="pIndex">1</span>/<span id="pMax"><?php echo ($comp_max_people); ?></span></label>
              </p>
            </div>
            <h2 id="section-3">参赛作品简介</h2>
            <div style="border-top: 1px solid #ddd">
              <p id="brief">
                <textarea placeholder='请输入作品简介，如果是比赛现场作品，可以不填'  name='b'  id='b'></textarea>
              </p>
            </div>
          </form>
          
          <form id="fileUploadForm" method="post" action='/custom/comp_apply/submitForm' enctype="multipart/form-data">  
            <h2 id="section-4">附件提交</h2>
            <a class="fileAlreadyExisted" style="cursor:pointer;margin: 15px 0px;">无上传文件，请在下方选择文件，并点击左边的保存按钮</a>  
            <div style="border-top: 1px solid #ddd;margin-top:15px;">
              <input type="text" id="comp_id" name="comp_id" value="<?php echo ($comp_id); ?>" style="display:none">	
              <input type="text" id="comp_item_id" name="comp_item_id" value="<?php echo ($comp_item_id); ?>" style="display:none">	
              <input type="file" id="compApplyFile" class="compApplyFile" name="compApplyFile">
            </div>
          </form>
       </div>
    </div>
</div>
<div style="height:200px"></div>
</body>
</html>