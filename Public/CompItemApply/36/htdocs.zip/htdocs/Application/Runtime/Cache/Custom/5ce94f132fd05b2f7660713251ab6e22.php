<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta http-equiv = "X-UA-Compatible" content = "chrome=1" />
<meta charset="UTF-8">
<title>Search People</title>
<link href="/Public/css/searchPeople.css" rel="stylesheet">
  <link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap.min.css" />
<link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table.css" />
<link rel="Stylesheet" type="text/css" href="/Public/css/bootstrap/bootstrap-table-filter.css" />
<link rel="stylesheet" type="text/css" href="/Public/jsLib/tooltipster-master/css/tooltipster.css" />
<link rel="stylesheet" type="text/css" href="/Public/jsLib/tooltipster-master/css/themes/tooltipster-noir.css" />
<link rel="Stylesheet" type="text/css" href="/Public/jsLib/myAlert/myAlert.css"/>


<link href="/Public/css/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="/Public/jsLib/PersonCard/personCard.css" rel="stylesheet">

<script src="/Public/jsLib/jquery/jquery.min.js"></script>
<script src="/Public/jsLib/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="/Public/jsLib/tooltipster-master/js/jquery.tooltipster.min.js"></script>
<script src="/Public/jsLib/PersonCard/personCard.js"></script>

<!-- 以下库用于输入检索的select option -->
<link rel="Stylesheet" type="text/css" href="/Public/jsLib/jquery-select/css/combo.select.css" />
<link rel="Stylesheet" type="text/css" href="/Public/jsLib/jquery-select/css/default.css" />

<script type="text/javascript">
	var app_url = "";
	var public_url = "/Public";
	var model_url = "/custom/search_people";
	var allAcademy;
	var allSelectedDirection = new Array();
	var allSelectedAbility = new Array();
</script>
</head>
<body>	
<div style='position: fixed; top: 0px;'>hello</div>
<nav class="navbar navbar-default" role="navigation" style="margin-bottom:0;position:relative;">
   <div class="navbar-header">
      <a class="navbar-brand" >找人</a>
   </div>
   <div class="navContainer">
      <!--向左对齐-->
      <ul class="nav navbar-nav navbar-left">
          <li class="dropdown dropdown1">
            <a id="abilitySearchToggle" class="dropdown-toggle" data-toggle="dropdown" style="cursor:pointer">
               根据能力检索用户 <b class="caret"></b>
            </a> 
         </li>
         
<!--         <li class="dropdown dropdown2">
            <a id="academySearchToggle" class="dropdown-toggle" data-toggle="dropdown"style="cursor:pointer">
               根据院系检索用户 <b class="caret"></b>
            </a> 
         </li>
 --> 
         <li style="margin-top: 5px;">
	         <form method="get" class="demo-form academySearchForm">
		         <select name="dt" required class="academySearchSelect">
					<option value="">输入关键字查找学院</option>
				</select>
			</form>
		</li>
      </ul>

      <!--向右对齐-->
      <ul class="nav navbar-nav navbar-right" style="margin: 0px auto;">
	      <form id="searchTextForm" class="navbar-form navbar-left" AUTOCOMPLETE="off">
	         <div class="form-group">
	            <input type="text" class="form-control" id="searchText" name="searchText"  placeholder="检索能力（输入完成请回车键确认）" style="width:250px">
	            <div id="searchResult" style="display:none"><div class="searchResultClose">×</div><div id="searchResultContent" ></div></div>
	         </div>
	      </form>  
      </ul>
   </div>
</nav>

<div class="abilitySearchBox" style="display:none;"><!-- 根据能力搜索下拉框 -->
 <div class="conditionContainer fieldTags">
 		<p class="fieldTitle searchTitle">领域</p>
 		<div class="searchContent" id="L1">			
 		</div>
 </div>
 <div class="divider"></div>
 <div  class="conditionContainer directionTags">
 		<p class="directionTitle searchTitle">方向</p>		
 		<div class="searchContent" id="L2">
 			<div class="titleTag">热门方向：</div>
 		</div>
 </div>
 <div class="divider"></div>
 <div class="conditionContainer abilityTags">
 		<p class="abilityTitle searchTitle">能力</p>	
 		<div  class="searchContent" id="L3">
 			<div class="titleTag">热门能力：</div> 			
 		</div>
 </div>
</div><!-- class="abilitySearchBox" -->

<div class="academySearchBox" style="display:none;"><!-- 根据学院搜索下拉框 -->
   <div class="conditionContainer">
   		<p class="academyTitle searchTitle">学院</p>
   		<div class="searchContent academyTags" id="academyTags"></div>
   </div>
   <div class="divider"></div>
   <div  class="conditionContainer">
   		<p class="departmentTitle searchTitle">系别</p>
   		<div class="searchContent departmentTags" id="departmentTags"></div>
   </div>
   <div class="divider"></div>
   <div class="conditionContainer">
   		<p class="majorTitle searchTitle">专业</p>
   		<div  class="searchContent majorTags" id="majorTags"></div>
   </div>
</div><!-- class="academySearchBox" -->

<div class="selectedCondition">
	<div class="row selectedConditionRow" style="margin-left:10px;padding-top:10px;">
		<b>搜索条件：</b>
	</div>
</div>

<div class="tableContent" id="resultContainer">
	
	</div>
	
	<div class="modal fade" id="noteModal" tabindex="-1" role="dialog" 
		   aria-labelledby="myModalLabel" aria-hidden="true">
		   <div class="modal-dialog">
		      <div class="modal-content">
		         <div class="modal-header">
		            <button type="button" class="close" data-dismiss="modal" 
		               aria-hidden="true">×
		            </button>
		            <h4 class="modal-title" id="myModalLabel">
		              	通知内容
		            </h4>
		         </div>
		         <div class="modal-body" id="detailShowContent">
		          <form class="bs-example bs-example-form" role="form" id="addNoteForm">
				    <div class="input-group">
				    	<span class="input-group-addon">内容</span>
				    	<textarea class="form-control comp_sponsor" id="user_note_detail" style="resize:none;width:500px;height:250px" maxlength="500" placeholder="填写内容"></textarea>
				    </div>  
	        	  </form>
				</div>
		         <div class="modal-footer">
		            <button type="button" class="btn btn-default" 
		               data-dismiss="modal">关闭
		            </button>
		            <button type="button" class="btn btn-primary" id='sendConfirm' data-dismiss="modal" >
		         		    确认
		            </button>
		         </div>
		      </div>
		   </div>
		</div>
  <!-- <div style="margin:10px 15px 15px;">
    <div id="filter-bar"> </div>
    <table id="searchTable" 
    	data-url="/Public/JSON/Comp.json"
        data-toolbar="#filter-bar" 
        data-toggle="table"
        data-card-view="true"
        data-height="800"
        data-sort-order="desc">
        <thead>
	        <tr>
	          <th data-field="name" data-width="200" data-align="left" data-sortable="true">姓名</th>
	          <th data-field="academy" data-width="450" data-align="left">院系</th>
	          <th data-field="major" data-width="100" data-align="left" data-sortable="true">专业</th>
	          <th data-field="grade" data-width="100" data-align="left" data-sortable="true">年级</th>
	          <th data-field="abilities" data-formatter="operateFormatter" data-events="operateEvents">相关能力</th>
	        </tr>
     	 </thead>
    </table>
  </div> -->

<script src="/Public/jsLib/jquery-select/js/jquery.combo.select.js"></script>  
<script>
	
</script>
<script src="/Public/js/home/searchPeople.js"></script>
</body>
</html>