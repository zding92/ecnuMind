<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" /> 
</head>

<body>
<div style="margin-left: -8px; margin-top: -10px;">
<img src="/Public/img/employ.png" style="margin:0 auto;">
<img src="/Public/img/employ.png" style="margin:0 auto;">
</div>
</body>

</html>