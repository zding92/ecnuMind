<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
  <meta http-equiv = "X-UA-Compatible" content = "chrome=1" />
  <meta charset="utf-8" /> 
  <link rel="Stylesheet" type="text/css" href="/Public/css/ItemControl.css"/>  
  <link rel="Stylesheet" type="text/css" href="/Public/jsLib/falling-confetti/css/reset.css"/> 
  <link rel="Stylesheet" type="text/css" href="/Public/jsLib/falling-confetti/css/style.css"/>  
  
</head>

<body style="background-color: #111">
<!-- <div style="
    margin-left: -8px;
    margin-top: -10px;
	">
<img src="/Public/img/employ.png" style="margin:0 auto;">
<img src="/Public/img/employ.png" style="margin:0 auto;">
</div>
 -->
 	<canvas id="world"></canvas>
 	<div class="EmployLine1">
 		We Need You
 	</div>
 	<div class="EmployLine2">
 		该功能页面目前还在开发
 	</div>
 	<div class="EmployLine3">
 		HTML,CSS,JS,PHP的人才们，欢迎加入我们
 	</div>
 	<div class="EmployLine4">
 		运营推广的人才们，欢迎加入我们
 	</div>
 	<div class="EmployLine5">
 		有意者请联系：13764051838 张 鼎
 	</div>
 	
	<script src="/Public/jsLib/falling-confetti/js/index.js"></script>
</body>

</html>