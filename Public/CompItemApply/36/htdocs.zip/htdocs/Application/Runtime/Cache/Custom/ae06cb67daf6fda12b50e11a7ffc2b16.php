<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
    <meta name="renderer" content="webkit">
  	<meta http-equiv = "X-UA-Compatible" content = "IE=edge,chrome=1" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script type="text/javascript" src="/Public/jsLib/jquery/jquery.min.js"></script>
	<link rel="stylesheet" href="/Public/css/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/Public/css/ability.css" rel="stylesheet"> 
	<link href="/Public/css/icheck/line/blue.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="/Public/jsLib/tooltipster-master/css/tooltipster.css" />
	<link rel="stylesheet" type="text/css" href="/Public/jsLib/tooltipster-master/css/themes/tooltipster-noir.css" />
	<link rel="stylesheet" type="text/css" href="/Public/css/abilityPopout.css" rel="stylesheet">
	<link rel="Stylesheet" type="text/css" href="/Public/jsLib/myAlert/myAlert.css"/>
	<link rel="stylesheet" href="/Public/jsLib/SweetAlert/sweetalert.css" type='text/css'>
	<link rel="stylesheet" href="/Public/jsLib/Metro/MetroCard.css" type='text/css'>
 	<link rel='stylesheet' href='/Public/jsLib/DirectionJump/jumpto.css' type='text/css'>
	<link rel="stylesheet" href="/Public/jsLib/AbilityCard/AbilityCard.css" type='text/css'>

	<script type="text/javascript" src="/Public/js/home/abilityNew.js"></script>
	<script type="text/javascript" src="/Public/jsLib/jquery/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/jsLib/bootstrap/bootstrap.min.js"></script>	
	<script type="text/javascript" src="/Public/jsLib/DirectionJump/jquery.jumpto.js"></script>	
	<script src="/Public/js/home/ability.js"></script>
	<script src="/Public/js/home/abilityMaintain.js"></script>	
	<script type="text/javascript" src="/Public/jsLib/tooltipster-master/js/jquery.tooltipster.min.js"></script>
    <script type="text/javascript" src="/Public/jsLib/jquery/jquery.icheck.js"></script>
	<script type="text/javascript" src="/Public/jsLib/SweetAlert/sweetalert.min.js"></script>
	<script type="text/javascript" src="/Public/jsLib/myAlert/myAlert.js"></script>
	<script type="text/javascript" src="/Public/jsLib/Metro/MetroCard.js"></script>	
	<script type="text/javascript" src="/Public/jsLib/AbilityCard/AbilityCard.js"></script>
	<script type="text/javascript" src="/Public/jsLib/jquery.color-2.1.2.js"></script>
	
	<script>
	    var app_url = "";
	    var public_url = "/Public";
	</script>
	
</head>
<body>
	<!-- <div class="abilityHead"style="background:url(/Public/img/abilityHead.png) no-repeat;">		
		<div class="abilitySearch" >
			<form class="abilitySearchForm">
				<input class="abilitySearchFormText" type=text>
				<button class="abilitySearchFormBtn">搜索能力</button>
			</form>
		</div>
	</div> -->
	<div class="navbar navbar-default" style="margin-bottom:0px">
		<form class="abilitySearch">
			<label class="abilitySearchFormLabel">个人能力管理</label>
			<input class="abilitySearchFormText"  type=text  placeholder="搜索你想要的能力">
			<button class="abilitySearchFormBtn">Search</button>
		</form>
		<form class="abilityAdd">
			<label class="abilityAddLabel">没有你想找的能力？</label>
			<input type="button" value="添加新的能力" class="abilityAddBtn"/>
		</form>		
	</div>
	<div class="container" id="metroContainer">
	</div>
	
		<!-- 此DIV为个人能力弹出窗口 -->
          <div class="theme-popover"> 
		  	<div class="popoutLine1">
		  		<p class="popoutAbilityName">高速PCB设计</p>
		  		<img src="/Public/img/popout/popoutLine1Right.png" alt="error">
		  		<div class="popoutLine1Right"> 
		  			<div class="popoutLine1Text">
			  			<div class="closure popoutLine1Save">保存</div> |
			  			<div class="closure popoutLine1Cancel">取消</div>
		  			</div>
		  		</div>
		  	</div>
		  	<div class="popoutLine2">
		  		<p class="popoutLine2Line1">
		  			<b>0人</b>会这项能力
		  		</p>
		  		<div class="popoutLine2Line2">
		  			能力标签：<b>通信工程、电子工程、数字电路</b>
		  		</div>
		  	</div>
		  	<div class="popoutLine3">
		  		<div class="popoutLine3Green">
		  			<div class="popoutLine3GreenText line3GreenUnselected">√</div>
		  		</div>
		  		<div class="popoutLine3Red">
		  			<div class="popoutLine3RedText line3Selected line3RedSelected"><b>目前未掌握</b>（若已掌握该能力，请点击绿色按钮）</div>
		  		</div>
		  		
		  	</div>
		  	<div class="popoutLine4">
		  		<div class="abilityDetailHead">
		  			<img src="/Public/img/popout/abilityDetailHead.png" alt="error">
		  			<h1>能力详细说明</h1>
		  		</div>
		  		<div class="abilityDetailContainer" style="z-index:99">
			  		<form>
			  			 <textarea class="abilityDetail" id="abilityDetail" placeholder="在此添加经历或认证，进一步说明此项能力"></textarea>
			  		</form>
			  		<div class="selfDetailTextCount">
			  			剩余<span id="selfDetailTextCountNumber_a" class="font-size:x-large">100</span>个字
			  		</div>
		  		</div>

		  	</div>
		  </div>
		  
		  <!-- 此DIV为自定义能力窗口 -->
          <div class="new-popover">
		  	<div class="addAbilityPopLine1">
		  		<p class="popoutAbilityName">添加自定义能力</p>
		  		<img src="/Public/img/popout/popoutLine1Right.png" alt="error">
		  		<div class="popoutLine1Right"> 
		  			<div class="popoutLine1Text">
			  			<div class="closure popoutLine1Save">保存</div> |
			  			<div class="closure popoutLine1Cancel">取消</div>
		  			</div>
		  		</div>
		  	</div>
		  	
		  	<div class="newAbilityContainer" >
		  	  	<div class="addAbilityPopLine2">
					<div class="addAbilityPopSelectDiv">
						<div class="addAbilityPopSelectDiv1">
						<label class="abilityNewLabel" >领域</label>
							<div class="selectMask">								
								<select id="cmbProvince"></select>
							</div>
						</div>
						<div class="addAbilityPopSelectDiv2">		
							<label class="abilityNewLabel">方向</label>
							<div class="selectMask">
								<select id="cmbCity"></select>
							</div>
						</div>
						  <select id="cmbArea" style="display:none"></select>
					</div>
			  	</div>
			  	<div class="addAbilityPopLine3">
			  		<div class="addAbilityName">
					  	<label class="abilityNewLabel" style="margin-left:0px;">能力</label>
				  		<input id="newAbilityName" type="text" placeholder="请输入你要添加的能力">
			  		</div>
			  	</div>
			  	<div class="addAbilityPopLine4">
			  		
			  		<div class="abilityDetailContainer" style="z-index:99">
				  		<form>
				  			 <textarea class="abilityDetail" id="newAbilityDetail" placeholder="在此添加经历或认证，进一步说明此项能力"></textarea>
				  		</form>
				  		<div class="selfDetailTextCount">
			  			剩余<span id="selfDetailTextCountNumber_n" style="font-size:x-large">100</span>个字
			  			</div>
			  		</div>
			  	</div>
		  	</div>

		  </div>

          <!-- 此DIV为推荐能力窗口 -->
		  <div class="recommend-popover" style="display: none;">
		  		<div class="similarAbilityPopLine1">
			  		<div class="similarAbilityPopLine1Left">
			  			<p class="similarAbilityTitle">相似的能力</p>
			  		</div>
			  		<img src="/Public/img/popout/popoutLine1Right.png" alt="error">
			  		<div class="similarAbilityPopLine1Right"> 
			  			<div class="popoutLine1Text">
				  			<div class="closure popoutLine1Cancel">取消</div>
			  			</div>
			  		</div>
		  		</div>
		  	
			  	<div class="similarAbilityContainer">
				  	<div class="similarAbilityPopLine2">
				  		<div class="similarAbilityPrompt">
				  		根据您的提交信息，我们为您推荐以下能力<br>
				  		请 <b>任选一个</b> 继续编辑
				  		</div>
				  	</div>
				  	<div class="similarAbilityPopLine3">
				  		<div class="similarAbilityGallery" style="z-index:99">
				  		</div>
				  	</div>
				  	<div class="similarAbilityPopLine4">
				  		<div class="oldAbilityText">
				  			没有发现想要添加的能力？
				  		</div>
				  		<div class="oldAbilityButton">
				  			继续添加自定义能力
				  		</div>
				  	</div>
		  		</div>
		  </div>
		  
		  <!-- 此DIV为弹出窗口之下的遮罩 -->
		  <div class="theme-popover-mask"></div>
		  <div class='messagePopOut' style='display:none;z-index:10000'>
	         <div class='messagePopText'>
	         </div>
	         <div class='messagePopButton'>
	       		OK
	         </div>        	
		  </div>	
	

</body>
</html>